from flask import Flask, redirect, render_template, request, session, url_for

from config import Config
from database import close_db, init_db
from utils import centavos_para_moeda


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)

    if test_config:
        app.config.update(test_config)

    with app.app_context():
        init_db()

    app.teardown_appcontext(close_db)

    from controllers.auth_controller import auth_bp
    from controllers.main_controller import main_bp
    from controllers.pedidos import pedido_bp
    from controllers.pratos_controller import prato_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(prato_bp)
    app.register_blueprint(pedido_bp)

    @app.before_request
    def verificar_autenticacao():
        # Revalida privilégios no banco a cada requisição autenticada.
        if session.get("usuario_id"):
            from models import usuario as usuario_model
            from database import get_db
            usuario = get_db().execute("SELECT tipo_acesso FROM usuarios WHERE id=?", (session["usuario_id"],)).fetchone()
            if usuario is None:
                session.clear()
            else:
                session["tipo_acesso"] = usuario["tipo_acesso"]
        # Visitantes podem navegar no cardápio e montar carrinho.
        # Login é necessário apenas para finalizar pedidos.
        rotas_publicas = {
            "auth.login", "auth.cadastro", "static", "prato.listar", "main.inicio",
            "pedido.nova", "pedido.adicionar", "pedido.alterar_quantidade",
            "pedido.remover", "pedido.limpar",
        }
        if request.endpoint is None:
            return None  # Deixa o Flask mostrar o erro 404 das URLs inexistentes.
        if not session.get("usuario_id") and request.endpoint not in rotas_publicas:
            return redirect(url_for("auth.login"))

    @app.context_processor
    def contexto_carrinho():
        """Permite abrir o mesmo carrinho lateral em qualquer página."""
        itens = session.get("carrinho", [])
        return {
            "carrinho": itens,
            "total": sum(item["preco_centavos"] * item["quantidade"] for item in itens),
            "quantidade_carrinho": sum(item["quantidade"] for item in itens),
        }

    @app.template_filter("moeda")
    def filtro_moeda(valor):
        return centavos_para_moeda(valor)

    @app.errorhandler(404)
    def pagina_nao_encontrada(e):
        return render_template("404.html"), 404

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)