// O carrinho é um painel lateral, não uma segunda coluna do cardápio.
(() => {
  const painel = document.getElementById('carrinho-lateral');
  const fundo = document.getElementById('fundo-carrinho');
  if (!painel || !fundo) return;

  let acionadorAnterior = null;
  const focoPossivel = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

  function abrir(acionador) {
    if (painel.classList.contains('aberto')) return;
    acionadorAnterior = acionador || document.activeElement;
    fundo.hidden = false;
    painel.classList.add('aberto');
    painel.setAttribute('aria-hidden', 'false');
    document.body.classList.add('carrinho-aberto');
    painel.querySelector('[data-fechar-carrinho]')?.focus();
  }

  function fechar() {
    if (!painel.classList.contains('aberto')) return;
    painel.classList.remove('aberto');
    painel.setAttribute('aria-hidden', 'true');
    fundo.hidden = true;
    document.body.classList.remove('carrinho-aberto');
    if (acionadorAnterior && document.contains(acionadorAnterior)) acionadorAnterior.focus();
    if (new URLSearchParams(location.search).get('carrinho') === 'aberto') {
      const url = new URL(location.href);
      url.searchParams.delete('carrinho');
      history.replaceState(null, '', url.pathname + url.search + url.hash);
    }
  }

  document.querySelectorAll('[data-abrir-carrinho]').forEach(acionador => {
    acionador.addEventListener('click', evento => {
      evento.preventDefault();
      abrir(acionador);
    });
  });
  document.querySelectorAll('[data-fechar-carrinho]').forEach(botao => botao.addEventListener('click', fechar));
  fundo.addEventListener('click', fechar);
  document.addEventListener('keydown', evento => {
    if (!painel.classList.contains('aberto')) return;
    if (evento.key === 'Escape') {
      evento.preventDefault();
      fechar();
      return;
    }
    if (evento.key !== 'Tab') return;
    const itens = [...painel.querySelectorAll(focoPossivel)].filter(el => el.getClientRects().length);
    if (!itens.length) return;
    const primeiro = itens[0];
    const ultimo = itens[itens.length - 1];
    if (evento.shiftKey && document.activeElement === primeiro) {
      evento.preventDefault(); ultimo.focus();
    } else if (!evento.shiftKey && document.activeElement === ultimo) {
      evento.preventDefault(); primeiro.focus();
    }
  });

  document.querySelectorAll('[data-toggle-senha]').forEach(botao => {
    botao.addEventListener('click', () => {
      const campo = document.getElementById('senha');
      if (!campo) return;
      const visivel = campo.type === 'password';
      campo.type = visivel ? 'text' : 'password';
      botao.setAttribute('aria-pressed', String(visivel));
      botao.setAttribute('aria-label', visivel ? 'Ocultar senha' : 'Mostrar senha');
      campo.focus();
    });
  });

  if (new URLSearchParams(location.search).get('carrinho') === 'aberto') {
    abrir(document.querySelector('.nav-cart'));
  }
})();
