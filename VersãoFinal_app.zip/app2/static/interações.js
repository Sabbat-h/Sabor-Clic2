
"use strict";

document.addEventListener("DOMContentLoaded", () => {

  // 1. Pesquisa dinâmica no cardápio
  const pesquisa = document.querySelector(
    '.pesquisa-cardapio input[name="busca"]'
  );

  const produtos = document.querySelectorAll(".produto-card");

  if (pesquisa) {
    pesquisa.addEventListener("input", () => {
      const texto = pesquisa.value.toLowerCase().trim();

      produtos.forEach((produto) => {
        const nome = produto.textContent.toLowerCase();

        produto.style.display =
          nome.includes(texto) ? "" : "none";
      });
    });
  }

  // 2. Confirmação de entrega no histórico
  const formularios = document.querySelectorAll(
    ".acoes-entrega form"
  );

  formularios.forEach((formulario) => {
    formulario.addEventListener("submit", (evento) => {
      const status = formulario.querySelector(
        'input[name="status"]'
      ).value;

      const confirmado = window.confirm(
        `Deseja marcar este pedido como "${status}"?`
      );

      if (!confirmado) {
        evento.preventDefault();
      }
    });
  });

});
