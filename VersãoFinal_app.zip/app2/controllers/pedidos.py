from io import BytesIO

from flask import Blueprint, abort, flash, redirect, render_template, request, send_file, session, url_for
from openpyxl import Workbook
from openpyxl.styles import Font

from models import pedido as pedido_model
from models import prato as prato_model


pedido_bp = Blueprint("pedido", __name__, url_prefix="/pedidos")


def _carrinho():
    return session.setdefault("carrinho", [])


@pedido_bp.get("")
def listar():
    if session.get("tipo_acesso") not in ("ADMIN", "COZINHEIRO"):
        abort(403)
    return render_template("pedidos.html", pedidos=pedido_model.listar())


@pedido_bp.get("/minha-fila")
def minha_fila():

    # Apenas clientes acessam esta página
    if session.get("tipo_acesso") != "CLIENTE":
        abort(403)

    # Busca somente os pedidos do cliente logado
    pedidos = pedido_model.listar(
        usuario_id=session["usuario_id"]
    )

    return render_template(
        "minha_fila.html",
        pedidos=pedidos
    )


@pedido_bp.post("/<int:pedido_id>/confirmar-recebimento")
def confirmar_recebimento(pedido_id):

    if session.get("tipo_acesso") != "CLIENTE":
        abort(403)

    pedido = pedido_model.buscar(pedido_id)

    # Impede confirmar pedidos de outras pessoas
    if pedido is None or pedido["usuario_id"] != session["usuario_id"]:
        abort(404)

    confirmado = pedido_model.confirmar_recebimento(
        pedido_id,
        session["usuario_id"]
    )

    if confirmado:
        flash(
            "Recebimento confirmado com sucesso!",
            "sucesso"
        )
    else:
        flash(
            "Este pedido ainda não pode ser confirmado.",
            "erro"
        )

    return redirect(url_for("pedido.minha_fila"))


@pedido_bp.get("/kds")
def fila_kds():
    if session.get("tipo_acesso") not in ["COZINHEIRO", "ADMIN"]:
        flash("Acesso permitido apenas para a equipe da cozinha.", "erro")
        return redirect(url_for("main.inicio"))
    return render_template("kds.html", pedidos=pedido_model.listar_fila_kds())




@pedido_bp.post("/<int:pedido_id>/status")
def atualizar_status(pedido_id):

    # Apenas ADMIN e COZINHEIRO podem alterar os pedidos
    if session.get("tipo_acesso") not in ("ADMIN", "COZINHEIRO"):
        abort(403)

    # Identifica de qual página veio a alteração
    pagina = (
        "pedido.fila_kds"
        if request.form.get("origem") == "cozinha"
        else "pedido.listar"
    )

    # Recebe o novo status enviado pelo formulário
    novo_status = request.form.get("status", "").strip()

    # Status permitidos para a equipe
    status_permitidos = (
        "Aguardando",
        "Em Preparo",
        "Pronto",
        "Em entrega",
        "Não entregue"
    )

    # Verifica se o status é válido
    if novo_status not in status_permitidos:
        flash(
            f"Status inválido: {novo_status or 'não informado'}.",
            "erro"
        )
        return redirect(url_for(pagina))

    # Procura o pedido no banco de dados
    pedido = pedido_model.buscar(pedido_id)

    if pedido is None:
        abort(404)

    # Não altera pedidos já confirmados pelo cliente
    if pedido["status"] == "Entregue":
        flash(
            "Este pedido já foi entregue e confirmado.",
            "erro"
        )
        return redirect(url_for(pagina))

    # Somente pedidos prontos podem sair para entrega
    if novo_status == "Em entrega" and pedido["status"] != "Pronto":
        flash(
            "Marque o pedido como Pronto antes de enviar para entrega.",
            "erro"
        )
        return redirect(url_for(pagina))

    # Impede voltar ao preparo após sair para entrega
    if pedido["status"] == "Em entrega" and novo_status in (
        "Aguardando",
        "Em Preparo",
        "Pronto"
    ):
        flash(
            "Este pedido já saiu para entrega.",
            "erro"
        )
        return redirect(url_for(pagina))

    # Atualiza o pedido no banco de dados
    pedido_model.atualizar_status(pedido_id, novo_status)

    # Mostra mensagem de sucesso
    flash(
        f"Pedido #{pedido_id} atualizado para: {novo_status}.",
        "sucesso"
    )

    # Retorna para a página de origem
    return redirect(url_for(pagina))




@pedido_bp.get("/nova")
def nova():
    return redirect(url_for("prato.listar", carrinho="aberto"))


@pedido_bp.post("/carrinho/adicionar")
def adicionar():
    try:
        prato_id = int(request.form.get("prato_id", ""))
        quantidade = int(request.form.get("quantidade", ""))
    except ValueError:
        prato_id, quantidade = 0, 0
    prato = prato_model.buscar(prato_id)
    if prato is None or quantidade <= 0:
        flash("Selecione um prato e uma quantidade válida.", "erro")
    elif quantidade > prato["estoque"]:
        flash("A quantidade supera o estoque disponível.", "erro")
    else:
        carrinho = _carrinho()
        existente = next((i for i in carrinho if i["prato_id"] == prato_id), None)
        nova_quantidade = quantidade + (existente["quantidade"] if existente else 0)
        if nova_quantidade > prato["estoque"]:
            flash("A quantidade total no carrinho supera o estoque.", "erro")
            return redirect(url_for("prato.listar", carrinho="aberto"))
        if existente:
            existente["quantidade"] = nova_quantidade
        else:
            carrinho.append({"prato_id": prato["id"], "nome": prato["nome"],
                             "preco_centavos": prato["preco_centavos"], "quantidade": quantidade})
        session["carrinho"] = carrinho
        flash("Prato adicionado ao carrinho.", "sucesso")
    return redirect(url_for("prato.listar", carrinho="aberto"))


@pedido_bp.post("/carrinho/<int:indice>/quantidade")
def alterar_quantidade(indice):
    carrinho = _carrinho()
    if indice < 0 or indice >= len(carrinho):
        abort(404)
    try:
        delta = int(request.form.get("delta", "0"))
    except ValueError:
        delta = 0
    if delta not in (-1, 1):
        abort(400)
    item = carrinho[indice]
    nova_quantidade = item["quantidade"] + delta
    prato = prato_model.buscar(item["prato_id"])
    if nova_quantidade <= 0:
        carrinho.pop(indice)
    elif prato is None or nova_quantidade > prato["estoque"]:
        flash("Quantidade indisponível em estoque.", "erro")
    else:
        item["quantidade"] = nova_quantidade
    session["carrinho"] = carrinho
    return redirect(url_for("prato.listar", carrinho="aberto"))


@pedido_bp.post("/carrinho/<int:indice>/remover")
def remover(indice):
    carrinho = _carrinho()
    if indice < 0 or indice >= len(carrinho):
        abort(404)
    carrinho.pop(indice)
    session["carrinho"] = carrinho
    return redirect(url_for("prato.listar", carrinho="aberto"))


@pedido_bp.post("/carrinho/limpar")
def limpar():
    session.pop("carrinho", None)
    flash("Carrinho esvaziado.", "sucesso")
    return redirect(url_for("prato.listar", carrinho="aberto"))


@pedido_bp.post("/finalizar")
def finalizar():
    carrinho = _carrinho()
    if not carrinho:
        flash("O carrinho está vazio.", "erro")
        return redirect(url_for("prato.listar", carrinho="aberto"))
    if not session.get("usuario_id"):
        flash("Faça login para finalizar a compra.", "erro")
        return redirect(url_for("auth.login"))
    try:
        pedido_id = pedido_model.finalizar(session["usuario_id"], carrinho)
    except ValueError as erro:
        flash(str(erro), "erro")
        return redirect(url_for("prato.listar", carrinho="aberto"))
    session.pop("carrinho", None)
    flash("Pedido realizado com sucesso.", "sucesso")
    return redirect(url_for("pedido.detalhes", pedido_id=pedido_id))


@pedido_bp.get("/<int:pedido_id>")
def detalhes(pedido_id):
    pedido = pedido_model.buscar(pedido_id)
    if pedido is None:
        abort(404)
    if session.get("tipo_acesso") not in ("ADMIN", "COZINHEIRO") and pedido["usuario_id"] != session.get("usuario_id"):
        abort(403)
    return render_template("detalhes_pedido.html", pedido=pedido,
                           itens=pedido_model.listar_itens(pedido_id))


@pedido_bp.get("/exportar")
def exportar():
    if session.get("tipo_acesso") not in ("ADMIN", "COZINHEIRO"):
        abort(403)
    wb = Workbook()
    ws = wb.active
    ws.title = "Pedidos"
    ws.append(["Código", "Data e hora", "Cliente", "Status", "Total (R$)"])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for p in pedido_model.listar():
        ws.append([p["id"], p["criado_em"], p["usuario_nome"], p["status"], p["total_centavos"] / 100])
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 25
    ws.column_dimensions["D"].width = 15
    for cell in ws["E"][1:]:
        cell.number_format = 'R$ #,##0.00'
    arquivo = BytesIO()
    wb.save(arquivo)
    arquivo.seek(0)
    return send_file(arquivo, as_attachment=True, download_name="pedidos_sabor_e_clic.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")