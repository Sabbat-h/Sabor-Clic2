"""Administração local das contas internas (nunca cria perfis pela rota pública)."""
import argparse
import getpass
import sqlite3

from werkzeug.security import generate_password_hash

from app import app
from database import get_db


def listar_equipe():
    """Mostra nomes, logins e funções sem expor senhas ou hashes."""
    with app.app_context():
        membros = get_db().execute(
            "SELECT nome, usuario, tipo_acesso FROM usuarios "
            "WHERE tipo_acesso IN ('ADMIN', 'COZINHEIRO') "
            "ORDER BY tipo_acesso, nome COLLATE NOCASE"
        ).fetchall()
    if not membros:
        print("Nenhum administrador ou cozinheiro está cadastrado neste banco.")
        return
    print("\nContas da equipe cadastradas neste banco:\n")
    for membro in membros:
        print(f"- {membro['tipo_acesso']}: {membro['nome']} (login: {membro['usuario']})")


def cadastrar_equipe():
    perfil = input("Perfil (ADMIN ou COZINHEIRO): ").strip().upper()
    if perfil not in {"ADMIN", "COZINHEIRO"}:
        raise SystemExit("Perfil inválido.")
    nome = input("Nome completo: ").strip()
    usuario = input("Usuário para login: ").strip()
    email = input("E-mail: ").strip().lower()
    senha = getpass.getpass("Senha (mínimo 8 caracteres): ")
    confirmar = getpass.getpass("Confirme a senha: ")
    if not all((nome, usuario, email)) or "@" not in email or len(senha) < 8 or senha != confirmar:
        raise SystemExit("Dados inválidos ou senhas diferentes.")
    with app.app_context():
        try:
            db = get_db()
            db.execute(
                "INSERT INTO usuarios(nome,usuario,email,senha_hash,tipo_acesso) VALUES (?,?,?,?,?)",
                (nome, usuario, email, generate_password_hash(senha), perfil),
            )
            db.commit()
        except sqlite3.IntegrityError:
            raise SystemExit("Usuário ou e-mail já cadastrado.")
    print("Usuário interno criado com sucesso. Entre pelo Login do site.")


def main():
    parser = argparse.ArgumentParser(description="Cadastrar ou listar contas internas do Sabor & Clic")
    parser.add_argument("--listar", action="store_true", help="Exibe administradores e cozinheiros cadastrados")
    args = parser.parse_args()
    if args.listar:
        listar_equipe()
    else:
        cadastrar_equipe()


if __name__ == "__main__":
    main()
