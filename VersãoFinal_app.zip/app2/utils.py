"""Conversão de valores monetários: o banco armazena sempre centavos inteiros."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


def moeda_para_centavos(valor_str):
    if not valor_str:
        return 0
    texto = str(valor_str).strip().replace("R$", "").replace(" ", "")
    # Aceita 12,90; 12.90 e 1.234,56 no formulário.
    if "," in texto:
        texto = texto.replace(".", "").replace(",", ".")
    try:
        reais = Decimal(texto)
        if not reais.is_finite():
            raise InvalidOperation
        return int((reais * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError):
        raise ValueError("Informe um preço válido, como 12,90.")


def centavos_para_moeda(valor):
    try:
        reais = Decimal(int(valor or 0)) / 100
        return f"R$ {reais:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
    except (ValueError, TypeError, InvalidOperation):
        return "R$ 0,00"
