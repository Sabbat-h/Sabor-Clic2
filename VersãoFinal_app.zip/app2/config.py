"""Configurações do projeto Sabor & Clic."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


class Config:
    # A chave padrão é apenas para desenvolvimento local.
    SECRET_KEY = os.environ.get("SECRET_KEY", "sabor-clic-apenas-desenvolvimento-local")
    DATABASE = os.environ.get("DATABASE", str(BASE_DIR / "sabor_e_clic.sqlite"))
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
