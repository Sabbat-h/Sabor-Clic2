"""Testes de integração do Sabor & Clic (banco isolado por teste)."""

from werkzeug.security import generate_password_hash
from database import get_db


def criar_prato(app, nome="Bolo de chocolate", preco=1850, estoque=5):
    with app.app_context():
        db = get_db()
        cursor = db.execute(
            "INSERT INTO pratos (nome, descricao, categoria, preco_centavos, estoque, ativo) "
            "VALUES (?, ?, ?, ?, ?, 1)",
            (nome, "Delicioso", "Bolos", preco, estoque),
        )
        db.commit()
        return cursor.lastrowid


def criar_usuario(app, nome="Maria", usuario="maria", senha="senha123", perfil="CLIENTE"):
    with app.app_context():
        db = get_db()
        db.execute(
            "INSERT INTO usuarios (nome,usuario,email,senha_hash,tipo_acesso) VALUES (?,?,?,?,?)",
            (nome, usuario, f"{usuario}@example.com", generate_password_hash(senha), perfil),
        )
        db.commit()


def test_agendamento_removido(client):
    pagina = client.get("/")
    assert pagina.status_code == 200
    assert "agendamento" not in pagina.get_data(as_text=True).lower()
    assert client.get("/agendamento").status_code == 404


def test_cabecalho_e_senha(client):
    pagina = client.get("/login").get_data(as_text=True)
    assert 'type="password"' in pagina
    assert 'data-toggle-senha' in pagina
    assert 'data-abrir-carrinho' in pagina
    assert 'id="carrinho-lateral"' in pagina
    assert 'aria-hidden="true"' in pagina
    assert 'nav-pill' in pagina


def test_cardapio_e_carrinho_publicos(client, app):
    prato_id = criar_prato(app)
    pagina = client.get('/pratos')
    assert pagina.status_code == 200
    assert 'Bolo de chocolate' in pagina.get_data(as_text=True)
    assert 'class="carrinho-lateral"' in pagina.get_data(as_text=True)
    resposta = client.post('/pedidos/carrinho/adicionar', data={'prato_id': prato_id, 'quantidade': 2})
    assert resposta.status_code == 302
    assert 'carrinho=aberto' in resposta.headers['Location']
    pagina = client.get(resposta.headers['Location']).get_data(as_text=True)
    assert 'R$ 37,00' in pagina
    assert 'Diminuir quantidade' in pagina
    assert 'Entrar para finalizar' in pagina
    assert client.post('/pedidos/carrinho/0/quantidade', data={'delta': -1}).status_code == 302
    assert client.post('/pedidos/carrinho/0/remover').status_code == 302
    with client.session_transaction() as sessao:
        assert not sessao.get('carrinho')


def test_login_preserva_carrinho_e_finaliza(client, app):
    prato_id = criar_prato(app)
    criar_usuario(app)
    client.post('/pedidos/carrinho/adicionar', data={'prato_id': prato_id, 'quantidade': 2})
    resposta = client.post('/login', data={'usuario': 'maria', 'senha': 'senha123'})
    assert resposta.status_code == 302
    with client.session_transaction() as sessao:
        assert sessao['carrinho'][0]['quantidade'] == 2
    resposta = client.post('/pedidos/finalizar', follow_redirects=True)
    assert resposta.status_code == 200
    assert 'R$ 37,00' in resposta.get_data(as_text=True)
    with app.app_context():
        db = get_db()
        assert db.execute('SELECT estoque FROM pratos WHERE id=?', (prato_id,)).fetchone()[0] == 3


def test_equipe_ve_historico(client, app):
    criar_usuario(app, nome="Administradora", usuario="admin", senha="senhaforte", perfil="ADMIN")
    client.post('/login', data={'usuario': 'admin', 'senha': 'senhaforte'})
    resposta = client.get('/pedidos')
    assert resposta.status_code == 200
    assert 'Histórico de Pedidos' in resposta.get_data(as_text=True)
    assert 'Entregue' in resposta.get_data(as_text=True)


def test_administrador_gerencia_cardapio_e_exporta(client, app):
    from io import BytesIO
    from openpyxl import load_workbook

    prato_id = criar_prato(app, nome="Bolo de chocolate")
    criar_usuario(app, nome="Responsável", usuario="gerente", senha="senha1234", perfil="ADMIN")
    assert client.post('/login', data={'usuario': 'gerente', 'senha': 'senha1234'}).status_code == 302

    pagina = client.get('/pratos').get_data(as_text=True)
    assert '+ Novo prato' in pagina
    assert 'Exportar Excel' in pagina
    assert 'Administrador' in pagina
    assert 'Histórico' in pagina
    assert 'Cozinha' in pagina

    edicao = client.get(f'/pratos/{prato_id}/editar')
    assert edicao.status_code == 200
    assert 'Excluir este prato' in edicao.get_data(as_text=True)

    xlsx = client.get('/pratos/exportar')
    assert xlsx.status_code == 200
    assert xlsx.mimetype == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    planilha = load_workbook(BytesIO(xlsx.data))
    assert planilha['Cardápio']['B2'].value == 'Bolo de chocolate'

    assert client.post(f'/pratos/{prato_id}/excluir').status_code == 302
    with app.app_context():
        assert get_db().execute('SELECT 1 FROM pratos WHERE id=?', (prato_id,)).fetchone() is None


def test_acesso_restrito_ao_historico_e_pratos(client, app):
    criar_usuario(app, nome="Cliente", usuario="cliente", senha="senha12345")
    criar_usuario(app, nome="Cozinheira", usuario="chef", senha="senha12345", perfil="COZINHEIRO")
    client.post('/login', data={'usuario': 'cliente', 'senha': 'senha12345'})
    assert client.get('/pedidos').status_code == 403
    assert client.get('/pedidos/kds').status_code == 302
    assert client.get('/pratos/exportar').status_code == 403
    assert client.get('/pratos/novo').status_code == 302

    client.get('/logout')
    client.post('/login', data={'usuario': 'chef', 'senha': 'senha12345'})
    assert client.get('/pedidos').status_code == 200
    assert client.get('/pedidos/kds').status_code == 200
    assert client.get('/pedidos/exportar').status_code == 200
    assert client.get('/pratos/exportar').status_code == 403
    pagina = client.get('/').get_data(as_text=True)
    assert 'Cozinheiro' in pagina
    assert 'Histórico' in pagina
