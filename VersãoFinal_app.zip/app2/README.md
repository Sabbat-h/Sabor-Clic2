# Sabor & Clic — cardápio e pedidos (Flask + MVC)

Aplicação web de sobremesas e refeições, com interface em rosa e vinho, criada em Python/Flask e SQLite. O projeto foi organizado em **Models, Controllers e Views** (templates Jinja2).

## Funcionalidades

- **Início:** apresentação do Sabor & Clic, pesquisa e atalhos.
- **Cardápio:** pesquisa, categorias, preços, fotos, disponibilidade e botão “Quero!”.
- **Carrinho lateral:** fica fechado enquanto a pessoa navega; abre pelo ícone 🛒 do cabeçalho, pelo botão da página inicial ou depois que um item é adicionado. Permite aumentar, diminuir e retirar produtos, fechando pelo X, fundo escurecido ou tecla Esc.
- **Cadastro e login:** conta pública do tipo CLIENTE, senhas protegidas com hash, campo de senha mascarado com opção para mostrar/ocultar.
- **Pedidos:** o cliente monta o carrinho antes de entrar, mas precisa fazer login para finalizar; após a compra, vê o comprovante de seu próprio pedido.
- **Equipe:** usuários COZINHEIRO e ADMIN consultam o histórico, a fila da cozinha e registram o status do preparo ou entrega. ADMIN também cadastra e edita os pratos.
- **Relatórios:** exportação do cardápio e dos pedidos para Excel, conforme as permissões da equipe.
- **Layout responsivo:** tela inicial, login, cadastro, cardápio e histórico adaptáveis a celular e computador.

**A funcionalidade de agendamento de bancadas foi removida.**

## Estrutura

```text
app2/
├── app.py                   # Flask, blueprints e autenticação
├── controllers/             # rotas e ações do sistema
├── models/                  # acesso ao banco e regras de negócio
├── templates/               # páginas HTML (Jinja2)
│   └── partials/            # carrinho lateral usado em todas as páginas
├── static/
│   ├── style.css            # estilos unificados e responsivos
│   ├── entrega_adicional.css # controles de status dos pedidos
│   ├── carrinho.js          # abrir e fechar o painel lateral
│   └── images/              # imagens do projeto
├── database.py              # conexão e criação das tabelas SQLite
├── sabor_e_clic.sqlite      # banco local incluído no projeto
├── criar_equipe.py          # cadastro de ADMIN ou COZINHEIRO
├── requirements.txt
└── tests/                   # testes de integração
```

## Executar no Windows 10/11 (PowerShell)

É necessário ter Python 3 instalado e acessível pelo comando `py`.

1. Abra o PowerShell na **pasta `app2`**, onde está o `app.py`.
2. Execute os comandos:

```powershell
py -m venv venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

3. Acesse **http://127.0.0.1:5000** no navegador.
4. Para encerrar o servidor, pressione `Ctrl+C` no PowerShell.

Se já houver uma pasta `venv` de outro computador, descarte-a e crie o ambiente novamente: ela **não deve ser copiada entre computadores**. O ZIP disponibilizado não inclui `venv`, pois as dependências são instaladas com o comando acima.

### macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

## Primeiros acessos

O banco recebido nesta versão não continha pratos nem usuários. As tabelas são criadas automaticamente, caso ainda não existam. Para cadastrar alguém da equipe, execute **em outro terminal, com o ambiente ativado**:

```powershell
python criar_equipe.py
```

Escolha `ADMIN` para poder adicionar pratos ou `COZINHEIRO` para acompanhar os pedidos. O programa pede nome, usuário, e-mail e senha. **Não há senha-padrão de administrador.** A senha é digitada no terminal sem exibir caracteres por segurança.

Para descobrir os usuários internos já cadastrados no banco da pasta atual:

```powershell
python criar_equipe.py --listar
```

Depois do login, o cabeçalho mostra **Nome · Administrador** ou **Nome · Cozinheiro**. Os links **Histórico** (`/pedidos`) e **Cozinha** (`/pedidos/kds`) aparecem apenas para a equipe. O cliente comum não pode acessar essas páginas.

**Gestão de pratos:** como ADMIN, abra **Cardápio → + Novo prato**. Para editar ou apagar um prato, clique em **Editar** no cartão do produto; na tela de edição há o botão **Excluir este prato** com confirmação. Para baixar a planilha do cardápio, use **Cardápio → Exportar Excel**. A página **Histórico** é restrita ao ADMIN e COZINHEIRO e permite conferir o status das entregas. O arquivo Excel dos pedidos está disponível também em `/pedidos/exportar`.

Se a interface continuar exibindo **Agendamento**, o Flask está rodando a pasta antiga. Pare o servidor com `Ctrl+C`, abra um terminal na pasta `app2` deste ZIP, execute `python app.py` e faça uma atualização completa do navegador com `Ctrl+Shift+R`.

Com a conta ADMIN conectada, abra **Cardápio → Novo prato** e cadastre pratos e estoque. O cadastro público da página **Cadastro** sempre gera um perfil CLIENTE.

## Fluxo do cliente

Acesse o cardápio → clique em **Quero!** → o carrinho abre pela direita → ajuste os itens → escolha **Entrar para finalizar** (se necessário) → conclua com **Finalizar pedido**. O carrinho permanece guardado quando a pessoa entra na conta.

## Testes

Com dependências instaladas e na pasta do projeto:

```powershell
python -m pytest -q
```

Os testes criam um banco temporário e não alteram os dados de uso normal do site.

## Observações

Esta aplicação usa o servidor Flask de desenvolvimento para demonstração local. Para publicação na internet, ainda é necessário configurar segredo de sessão a partir do ambiente, HTTPS e proteção contra CSRF em formulários.
